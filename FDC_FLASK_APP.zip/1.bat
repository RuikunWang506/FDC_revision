@echo on
cd "C:\FDC_FLASK_APP"

start pythonw "C:\FDC_FLASK_APP\app.py"